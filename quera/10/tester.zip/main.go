package main

type Car struct {
	// TODO
}

func NewCar(speed, battery int) *Car {
	// TODO
	return nil
}
func GetSpeed(car *Car) int {
	// TODO
	return 0
}
func GetBattery(car *Car) int {
	// TODO
	return 0
}
func ChargeCar(car *Car, minutes int) {
	// TODO
}
func TryFinish(car *Car, distance int) string {
	// TODO
	return ""
}
